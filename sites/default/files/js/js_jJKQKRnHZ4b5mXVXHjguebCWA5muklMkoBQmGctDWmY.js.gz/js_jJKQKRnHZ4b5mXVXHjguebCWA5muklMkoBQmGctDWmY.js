jQuery(document).ready(function(){
jQuery("#fbicon").hover(
function () {
    jQuery(this).attr("src","http://andrewjalexander.com/sites/all/themes/andy/images/nohoverfb.png");
},
function () {
    jQuery(this).attr("src","http://andrewjalexander.com/sites/all/themes/andy/images/fb.png");
});

jQuery("#linkedinicon").hover(
function () {
    jQuery(this).attr("src","http://andrewjalexander.com/sites/all/themes/andy/images/nohoverlinkedin.png");
},
function () {
    jQuery(this).attr("src","http://andrewjalexander.com/sites/all/themes/andy/images/linkedin.png");
});

jQuery("#googleplusicon").hover(
function () {
    jQuery(this).attr("src","http://andrewjalexander.com/sites/all/themes/andy/images/nohovergoogle+.png");
},
function () {
    jQuery(this).attr("src","http://andrewjalexander.com/sites/all/themes/andy/images/google+.png");
});

jQuery("#youtubeicon").hover(
function () {
    jQuery(this).attr("src","http://andrewjalexander.com/sites/all/themes/andy/images/nohoveryoutube.png");
},
function () {
    jQuery(this).attr("src","http://andrewjalexander.com/sites/all/themes/andy/images/youtube.png");
});

jQuery("#twittericon").hover(
function () {
    jQuery(this).attr("src","http://andrewjalexander.com/sites/all/themes/andy/images/nohovertwitter.png");
},
function () {
    jQuery(this).attr("src","http://andrewjalexander.com/sites/all/themes/andy/images/twitter.png");
});

jQuery("#emailicon").hover(
function () {
    jQuery(this).attr("src","http://andrewjalexander.com/sites/all/themes/andy/images/nohoveremail.png");
},
function () {
    jQuery(this).attr("src","http://andrewjalexander.com/sites/all/themes/andy/images/email.png");
});});
;
